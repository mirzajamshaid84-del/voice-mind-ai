interface AchievementCard {
  streak: number
  completed: number
  total: number
  summary: string | null
}

function wrapLines(ctx: CanvasRenderingContext2D, text: string, maxWidth: number) {
  const words = text.split(/\s+/)
  const lines: string[] = []
  let line = ''
  for (const word of words) {
    const test = line ? `${line} ${word}` : word
    if (ctx.measureText(test).width > maxWidth && line) {
      lines.push(line)
      line = word
    } else {
      line = test
    }
  }
  if (line) lines.push(line)
  return lines
}

function drawCard({ streak, completed, total, summary }: AchievementCard) {
  const W = 1080
  const H = 1920
  const canvas = document.createElement('canvas')
  canvas.width = W
  canvas.height = H
  const ctx = canvas.getContext('2d')
  if (!ctx) throw new Error('Canvas unsupported')

  ctx.fillStyle = '#0b0d1a'
  ctx.fillRect(0, 0, W, H)

  const glow = (x: number, y: number, r: number, color: string) => {
    const g = ctx.createRadialGradient(x, y, 0, x, y, r)
    g.addColorStop(0, color)
    g.addColorStop(1, 'transparent')
    ctx.fillStyle = g
    ctx.fillRect(0, 0, W, H)
  }
  glow(200, 300, 800, 'rgba(34, 211, 238, 0.35)')
  glow(900, 1600, 900, 'rgba(168, 85, 247, 0.4)')

  ctx.textAlign = 'center'
  ctx.fillStyle = '#67e8f9'
  ctx.font = '600 44px system-ui, sans-serif'
  ctx.fillText('VOICEMIND AI · DAILY ACHIEVEMENT', W / 2, 220)

  ctx.fillStyle = '#ffffff'
  ctx.font = '800 320px system-ui, sans-serif'
  ctx.fillText(`${completed}`, W / 2, 720)
  ctx.font = '500 56px system-ui, sans-serif'
  ctx.fillStyle = 'rgba(255,255,255,0.75)'
  ctx.fillText(`of ${total} tasks done today`, W / 2, 820)

  const pct = total ? completed / total : 0
  const barX = 160
  const barW = W - 320
  ctx.fillStyle = 'rgba(255,255,255,0.12)'
  ctx.beginPath()
  ctx.roundRect(barX, 900, barW, 36, 18)
  ctx.fill()
  const grad = ctx.createLinearGradient(barX, 0, barX + barW, 0)
  grad.addColorStop(0, '#22d3ee')
  grad.addColorStop(1, '#a855f7')
  ctx.fillStyle = grad
  ctx.beginPath()
  ctx.roundRect(barX, 900, Math.max(36, barW * pct), 36, 18)
  ctx.fill()

  ctx.fillStyle = '#ffffff'
  ctx.font = '700 96px system-ui, sans-serif'
  ctx.fillText(`${streak}-day streak`, W / 2, 1120)

  if (summary) {
    ctx.font = '400 50px system-ui, sans-serif'
    ctx.fillStyle = 'rgba(255,255,255,0.88)'
    wrapLines(ctx, summary, W - 240)
      .slice(0, 7)
      .forEach((line, i) => ctx.fillText(line, W / 2, 1290 + i * 72))
  }

  ctx.fillStyle = 'rgba(255,255,255,0.55)'
  ctx.font = '500 40px system-ui, sans-serif'
  ctx.fillText('Plan your day by voice with VoiceMind AI', W / 2, H - 140)

  return canvas
}

export async function shareAchievement(card: AchievementCard) {
  const canvas = drawCard(card)
  const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, 'image/png'))
  if (!blob) throw new Error('Could not create image')
  const file = new File([blob], 'voicemind-achievement.png', { type: 'image/png' })
  const text = `I finished ${card.completed} tasks today and I'm on a ${card.streak}-day streak with VoiceMind AI!`

  if (navigator.canShare?.({ files: [file] })) {
    try {
      await navigator.share({ files: [file], text })
      return 'shared'
    } catch (err) {
      if ((err as Error).name === 'AbortError') return 'cancelled'
    }
  }
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = file.name
  a.click()
  URL.revokeObjectURL(url)
  return 'downloaded'
}
