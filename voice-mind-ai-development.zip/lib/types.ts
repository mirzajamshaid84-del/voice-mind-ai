export type Category = 'work' | 'personal' | 'shopping' | 'urgent' | 'ideas'
export type TaskKind = 'task' | 'event' | 'note'
export type Mood = 'great' | 'good' | 'okay' | 'low' | 'stressed'
export type VoiceLang = 'en-US' | 'ur-PK' | 'hi-IN' | 'en-IN'

export interface Task {
  id: string
  title: string
  kind: TaskKind
  category: Category
  dueDate: string | null
  reminderTime: string | null
  completed: boolean
  completedAt: number | null
  createdAt: number
  sourceText: string
}

export interface ParsedItem {
  title: string
  kind: TaskKind
  category: Category
  dueDate: string | null
  reminderTime: string | null
}

export interface AppState {
  tasks: Task[]
  moods: Record<string, Mood>
  summaries: Record<string, string>
  voiceUsage: { day: string; count: number }
  voiceLang: VoiceLang
  isPro: boolean
}
