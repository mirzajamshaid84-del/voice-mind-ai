'use client'

import { useSyncExternalStore } from 'react'
import { dayKey } from './date'
import type { AppState, Mood, Task, VoiceLang } from './types'

const STORAGE_KEY = 'voicemind:v1'
export const FREE_DAILY_VOICE_LIMIT = 10

const initialState: AppState = {
  tasks: [],
  moods: {},
  summaries: {},
  voiceUsage: { day: '', count: 0 },
  voiceLang: 'en-US',
  isPro: false,
}

let state: AppState = initialState
let loaded = false
const listeners = new Set<() => void>()

function ensureLoaded() {
  if (loaded || typeof window === 'undefined') return
  loaded = true
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY)
    if (raw) state = { ...initialState, ...JSON.parse(raw) }
  } catch {
    state = initialState
  }
}

function commit(next: AppState) {
  state = next
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next))
  } catch {
    // Storage can be full or disabled (private mode); keep the in-memory state.
  }
  listeners.forEach((l) => l())
}

function subscribe(listener: () => void) {
  listeners.add(listener)
  const onStorage = (e: StorageEvent) => {
    if (e.key !== STORAGE_KEY) return
    loaded = false
    ensureLoaded()
    listener()
  }
  window.addEventListener('storage', onStorage)
  return () => {
    listeners.delete(listener)
    window.removeEventListener('storage', onStorage)
  }
}

export function useAppState() {
  return useSyncExternalStore(
    subscribe,
    () => {
      ensureLoaded()
      return state
    },
    () => initialState,
  )
}

export function voiceCreditsUsed(s: AppState) {
  return s.voiceUsage.day === dayKey() ? s.voiceUsage.count : 0
}

export function hasVoiceCredit(s: AppState) {
  return s.isPro || voiceCreditsUsed(s) < FREE_DAILY_VOICE_LIMIT
}

export const actions = {
  addTasks(tasks: Task[]) {
    commit({ ...state, tasks: [...tasks, ...state.tasks] })
  },
  toggleTask(id: string) {
    commit({
      ...state,
      tasks: state.tasks.map((t) =>
        t.id === id
          ? { ...t, completed: !t.completed, completedAt: t.completed ? null : Date.now() }
          : t,
      ),
    })
  },
  deleteTask(id: string) {
    commit({ ...state, tasks: state.tasks.filter((t) => t.id !== id) })
  },
  setMood(mood: Mood) {
    commit({ ...state, moods: { ...state.moods, [dayKey()]: mood } })
  },
  setSummary(text: string) {
    commit({ ...state, summaries: { ...state.summaries, [dayKey()]: text } })
  },
  setVoiceLang(voiceLang: VoiceLang) {
    commit({ ...state, voiceLang })
  },
  consumeVoiceCredit() {
    const today = dayKey()
    commit({ ...state, voiceUsage: { day: today, count: voiceCreditsUsed(state) + 1 } })
  },
}
