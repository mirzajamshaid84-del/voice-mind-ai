import type { Task } from './types'

export function dayKey(input: Date | number = new Date()) {
  const d = typeof input === 'number' ? new Date(input) : input
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

export function lastNDays(n: number) {
  const days: Date[] = []
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date()
    d.setDate(d.getDate() - i)
    days.push(d)
  }
  return days
}

export function computeStreak(tasks: Task[]) {
  const activeDays = new Set(
    tasks.filter((t) => t.completedAt).map((t) => dayKey(t.completedAt as number)),
  )
  const cursor = new Date()
  if (!activeDays.has(dayKey(cursor))) cursor.setDate(cursor.getDate() - 1)
  let streak = 0
  while (activeDays.has(dayKey(cursor))) {
    streak++
    cursor.setDate(cursor.getDate() - 1)
  }
  return streak
}

export function peakCompletionHours(tasks: Task[]) {
  const counts = new Map<number, number>()
  for (const t of tasks) {
    if (!t.completedAt) continue
    const h = new Date(t.completedAt).getHours()
    counts.set(h, (counts.get(h) ?? 0) + 1)
  }
  return [...counts.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3)
    .map(([h]) => h)
}

export function isTodayTask(t: Task, today = dayKey()) {
  if (t.kind === 'note') return false
  if (t.dueDate) return t.dueDate === today
  if (t.completedAt && dayKey(t.completedAt) === today) return true
  return dayKey(t.createdAt) === today
}

export function formatDue(t: Task, today = dayKey()) {
  const parts: string[] = []
  if (t.dueDate && t.dueDate !== today) {
    const [y, m, d] = t.dueDate.split('-').map(Number)
    parts.push(new Date(y, m - 1, d).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }))
  }
  if (t.reminderTime) {
    const [h, min] = t.reminderTime.split(':').map(Number)
    const date = new Date()
    date.setHours(h, min)
    parts.push(date.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' }))
  }
  return parts.join(' · ')
}
