import {
  Angry,
  Briefcase,
  Frown,
  Laugh,
  Lightbulb,
  Meh,
  ShoppingCart,
  Smile,
  User,
  Zap,
  type LucideIcon,
} from 'lucide-react'
import type { Category, Mood, VoiceLang } from './types'

export const CATEGORIES: Record<
  Category,
  { label: string; icon: LucideIcon; text: string; bg: string; bar: string }
> = {
  work: { label: 'Work', icon: Briefcase, text: 'text-primary', bg: 'bg-primary/15', bar: 'bg-primary' },
  personal: { label: 'Personal', icon: User, text: 'text-accent', bg: 'bg-accent/15', bar: 'bg-accent' },
  shopping: { label: 'Shopping', icon: ShoppingCart, text: 'text-chart-3', bg: 'bg-chart-3/15', bar: 'bg-chart-3' },
  urgent: { label: 'Urgent', icon: Zap, text: 'text-destructive', bg: 'bg-destructive/15', bar: 'bg-destructive' },
  ideas: { label: 'Ideas', icon: Lightbulb, text: 'text-chart-4', bg: 'bg-chart-4/15', bar: 'bg-chart-4' },
}

export const CATEGORY_KEYS = Object.keys(CATEGORIES) as Category[]

export const MOODS: { value: Mood; label: string; icon: LucideIcon }[] = [
  { value: 'great', label: 'Great', icon: Laugh },
  { value: 'good', label: 'Good', icon: Smile },
  { value: 'okay', label: 'Okay', icon: Meh },
  { value: 'low', label: 'Low', icon: Frown },
  { value: 'stressed', label: 'Stressed', icon: Angry },
]

export const VOICE_LANGS: { value: VoiceLang; label: string }[] = [
  { value: 'en-US', label: 'English' },
  { value: 'en-IN', label: 'Roman Urdu' },
  { value: 'ur-PK', label: 'اردو' },
  { value: 'hi-IN', label: 'हिन्दी' },
]
