'use client'

import { useCallback, useEffect, useRef, useState } from 'react'

interface RecognitionResultList {
  length: number
  [index: number]: { isFinal: boolean; 0: { transcript: string } }
}

interface Recognition {
  lang: string
  continuous: boolean
  interimResults: boolean
  start(): void
  stop(): void
  abort(): void
  onresult: ((event: { results: RecognitionResultList }) => void) | null
  onerror: ((event: { error: string }) => void) | null
  onend: (() => void) | null
}

type RecognitionCtor = new () => Recognition

function getRecognitionCtor(): RecognitionCtor | null {
  if (typeof window === 'undefined') return null
  const w = window as unknown as { SpeechRecognition?: RecognitionCtor; webkitSpeechRecognition?: RecognitionCtor }
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null
}

export function isSpeechSupported() {
  return getRecognitionCtor() !== null
}

export function useSpeechRecognition(lang: string, onFinished: (transcript: string) => void) {
  const recognitionRef = useRef<Recognition | null>(null)
  const transcriptRef = useRef('')
  const onFinishedRef = useRef(onFinished)
  onFinishedRef.current = onFinished

  const [listening, setListening] = useState(false)
  const [transcript, setTranscript] = useState('')
  const [error, setError] = useState<string | null>(null)

  const start = useCallback(() => {
    const Ctor = getRecognitionCtor()
    if (!Ctor) {
      setError('Voice input is not supported in this browser. Type your note instead.')
      return
    }
    recognitionRef.current?.abort()
    const rec = new Ctor()
    rec.lang = lang
    rec.continuous = true
    rec.interimResults = true
    rec.onresult = (event) => {
      let text = ''
      for (let i = 0; i < event.results.length; i++) text += `${event.results[i][0].transcript} `
      transcriptRef.current = text.trim()
      setTranscript(transcriptRef.current)
    }
    rec.onerror = (event) => {
      if (event.error === 'aborted') return
      setError(
        event.error === 'not-allowed' || event.error === 'service-not-allowed'
          ? 'Microphone access was blocked. Allow it, or type your note instead.'
          : event.error === 'no-speech'
            ? "Didn't catch that. Tap the mic and try again."
            : 'Voice input failed. Try again or type instead.',
      )
    }
    rec.onend = () => {
      setListening(false)
      onFinishedRef.current(transcriptRef.current)
    }

    transcriptRef.current = ''
    setTranscript('')
    setError(null)
    try {
      rec.start()
      recognitionRef.current = rec
      setListening(true)
    } catch {
      setError('Could not start the microphone. Type your note instead.')
    }
  }, [lang])

  const stop = useCallback(() => recognitionRef.current?.stop(), [])

  useEffect(() => () => recognitionRef.current?.abort(), [])

  return { listening, transcript, error, start, stop }
}
