import { AppShell } from '@/components/voicemind/app-shell'

export default function Page() {
  return <AppShell />
}
