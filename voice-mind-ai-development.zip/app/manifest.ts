import type { MetadataRoute } from 'next'

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'VoiceMind AI: Personal Assistant & Task Planner',
    short_name: 'VoiceMind',
    description: 'Voice-first AI task planner with streaks and daily insights.',
    start_url: '/',
    display: 'standalone',
    orientation: 'portrait',
    background_color: '#0b0d1a',
    theme_color: '#0b0d1a',
    categories: ['productivity', 'lifestyle'],
    icons: [
      { src: '/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any' },
      { src: '/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
    ],
  }
}
