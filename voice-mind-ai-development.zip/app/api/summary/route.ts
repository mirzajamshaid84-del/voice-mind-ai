import { generateText } from 'ai'
import { z } from 'zod'

export const maxDuration = 30

const requestSchema = z.object({
  completed: z.array(z.string().max(200)).max(30),
  pendingCount: z.number().int().min(0).max(1000),
  mood: z.enum(['great', 'good', 'okay', 'low', 'stressed']).nullable(),
  streak: z.number().int().min(0).max(10000),
})

export async function POST(req: Request) {
  const parsed = requestSchema.safeParse(await req.json().catch(() => null))
  if (!parsed.success) {
    return Response.json({ error: 'Invalid request' }, { status: 400 })
  }
  const { completed, pendingCount, mood, streak } = parsed.data

  try {
    const { text } = await generateText({
      model: 'google/gemini-3.5-flash',
      system:
        'You write warm, specific end-of-day reflections for a productivity app. Write exactly 2 short sentences, under 45 words total. First sentence: acknowledge what they achieved. Second: a motivating nudge for tomorrow that fits their mood. No emojis, no hashtags, no quotes. Reply in English unless the task titles are mostly in another language, then use that language.',
      prompt: `Completed today (${completed.length}): ${completed.join('; ') || 'nothing yet'}
Still pending: ${pendingCount}
Mood today: ${mood ?? 'not logged'}
Current streak: ${streak} day(s)`,
    })
    return Response.json({ summary: text.trim() })
  } catch (error) {
    console.error('[summary] generation failed', error)
    return Response.json({ error: 'Could not generate summary right now.' }, { status: 502 })
  }
}
