import { generateText, Output } from 'ai'
import { z } from 'zod'

export const maxDuration = 30

const requestSchema = z.object({
  text: z.string().trim().min(1).max(2000),
  today: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  now: z.string().regex(/^\d{2}:\d{2}$/),
  weekday: z.string().max(12),
  peakHours: z.array(z.number().int().min(0).max(23)).max(5),
})

const itemSchema = z.object({
  title: z
    .string()
    .describe('Short actionable title (max ~8 words) in the same language and script the user used'),
  kind: z.enum(['task', 'event', 'note']),
  category: z.enum(['work', 'personal', 'shopping', 'urgent', 'ideas']),
  dueDate: z.string().nullable().describe('YYYY-MM-DD, or null if no date was implied'),
  reminderTime: z.string().nullable().describe('HH:MM 24-hour reminder time, or null'),
})

export async function POST(req: Request) {
  const parsed = requestSchema.safeParse(await req.json().catch(() => null))
  if (!parsed.success) {
    return Response.json({ error: 'Invalid request' }, { status: 400 })
  }
  const { text, today, now, weekday, peakHours } = parsed.data

  try {
    const { output } = await generateText({
      model: 'google/gemini-3.5-flash',
      output: Output.object({ schema: z.object({ items: z.array(itemSchema) }) }),
      system: `You turn a user's voice note into structured items for a personal planner.
The note may be in English, Urdu (Arabic script), Hindi (Devanagari), or Roman Urdu / Hinglish. Understand all of them.
Rules:
- Split the note into separate items when the user mentions multiple things.
- kind: "event" for meetings/appointments at a set time, "note" for thoughts or info to remember, otherwise "task".
- category: urgent (explicitly urgent/asap/zaroori), shopping (buying things, groceries), work (job, office, clients, study), ideas (ideas, brainstorms), otherwise personal.
- Resolve relative dates ("kal", "tomorrow", "parso", "Friday") against today's date. Items with no date: dueDate = today for tasks, null for notes.
- reminderTime: use the time the user said. If none, suggest one later than the current time on the due day, preferring the user's most productive hours if given.
- Keep titles in the language and script the user spoke.
- Return at most 10 items.`,
      prompt: `Today is ${weekday}, ${today}. Current time ${now}. User's most productive hours: ${
        peakHours.length ? peakHours.map((h) => `${h}:00`).join(', ') : 'unknown'
      }.\n\nVoice note:\n"""${text}"""`,
    })

    const items = output.items.slice(0, 10).map((item) => ({
      ...item,
      title: item.title.slice(0, 140),
      dueDate: item.dueDate && /^\d{4}-\d{2}-\d{2}$/.test(item.dueDate) ? item.dueDate : null,
      reminderTime:
        item.reminderTime && /^([01]\d|2[0-3]):[0-5]\d$/.test(item.reminderTime) ? item.reminderTime : null,
    }))

    return Response.json({ items })
  } catch (error) {
    console.error('[parse] generation failed', error)
    return Response.json({ error: 'AI could not process that note. Please try again.' }, { status: 502 })
  }
}
