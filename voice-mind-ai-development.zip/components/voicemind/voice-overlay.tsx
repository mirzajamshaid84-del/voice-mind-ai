'use client'

import { Check, LoaderCircle, Mic, Square, Wand2, X } from 'lucide-react'
import { useEffect, useState } from 'react'
import { isSpeechSupported, useSpeechRecognition } from '@/hooks/use-speech-recognition'
import { dayKey, peakCompletionHours } from '@/lib/date'
import { CATEGORIES, VOICE_LANGS } from '@/lib/meta'
import { actions } from '@/lib/store'
import type { AppState, ParsedItem } from '@/lib/types'
import { cn } from '@/lib/utils'

type Phase = 'capture' | 'processing' | 'review'

export function VoiceOverlay({ state, onClose }: { state: AppState; onClose: () => void }) {
  const [text, setText] = useState('')
  const [phase, setPhase] = useState<Phase>('capture')
  const [items, setItems] = useState<ParsedItem[]>([])
  const [error, setError] = useState<string | null>(null)
  const speech = useSpeechRecognition(state.voiceLang, (finalText) => {
    if (finalText) setText(finalText)
  })
  const supported = isSpeechSupported()

  useEffect(() => {
    if (supported) speech.start()
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
    // Start listening once when the overlay opens.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const displayText = speech.listening ? speech.transcript : text

  async function process() {
    const note = displayText.trim()
    if (!note) return
    if (speech.listening) speech.stop()
    setPhase('processing')
    setError(null)
    const now = new Date()
    try {
      const res = await fetch('/api/parse', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: note.slice(0, 2000),
          today: dayKey(now),
          now: `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`,
          weekday: now.toLocaleDateString('en-US', { weekday: 'long' }),
          peakHours: peakCompletionHours(state.tasks),
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      if (!data.items.length) throw new Error("Couldn't find any tasks in that. Try rephrasing.")
      actions.consumeVoiceCredit()
      setItems(data.items)
      setPhase('review')
    } catch (err) {
      setError((err as Error).message || 'Something went wrong.')
      setPhase('capture')
    }
  }

  function save() {
    const now = Date.now()
    actions.addTasks(
      items.map((item, i) => ({
        ...item,
        id: crypto.randomUUID(),
        completed: false,
        completedAt: null,
        createdAt: now - i,
        sourceText: text,
      })),
    )
    onClose()
  }

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="voice-title"
      className="fixed inset-0 z-50 mx-auto flex max-w-md flex-col bg-background/95 px-5 pt-5 pb-[max(1.25rem,env(safe-area-inset-bottom))] backdrop-blur-xl animate-in fade-in"
    >
      <div className="flex items-center justify-between">
        <h2 id="voice-title" className="text-lg font-semibold">
          {phase === 'review' ? 'Review & save' : 'Voice assistant'}
        </h2>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close"
          className="rounded-full p-2 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
        >
          <X className="size-5" aria-hidden="true" />
        </button>
      </div>

      {phase === 'review' ? (
        <div className="flex flex-1 flex-col gap-4 overflow-y-auto pt-4">
          <p className="text-sm text-muted-foreground">
            AI organized your note into {items.length} {items.length === 1 ? 'item' : 'items'}.
          </p>
          <ul className="flex flex-col gap-2">
            {items.map((item, i) => {
              const cat = CATEGORIES[item.category]
              const Icon = cat.icon
              return (
                <li key={i} className="flex items-start gap-3 rounded-2xl border border-border bg-card p-3.5 animate-in fade-in slide-in-from-bottom-2" style={{ animationDelay: `${i * 60}ms` }}>
                  <span className={cn('flex size-9 shrink-0 items-center justify-center rounded-xl', cat.bg, cat.text)}>
                    <Icon className="size-4" aria-hidden="true" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p dir="auto" className="text-sm font-medium">{item.title}</p>
                    <p className="mt-0.5 text-xs text-muted-foreground capitalize">
                      {item.kind} · {cat.label}
                      {item.dueDate && ` · ${item.dueDate}`}
                      {item.reminderTime && ` · ${item.reminderTime}`}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setItems((prev) => prev.filter((_, j) => j !== i))}
                    aria-label={`Remove "${item.title}"`}
                    className="rounded-lg p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground"
                  >
                    <X className="size-4" aria-hidden="true" />
                  </button>
                </li>
              )
            })}
          </ul>
          <div className="mt-auto flex gap-2">
            <button
              type="button"
              onClick={() => setPhase('capture')}
              className="flex-1 rounded-xl border border-border px-4 py-3 text-sm font-semibold hover:bg-muted"
            >
              Back
            </button>
            <button
              type="button"
              onClick={save}
              disabled={!items.length}
              className="flex flex-[2] items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-primary to-accent px-4 py-3 text-sm font-semibold text-primary-foreground disabled:opacity-50"
            >
              <Check className="size-4" aria-hidden="true" />
              Save {items.length} {items.length === 1 ? 'item' : 'items'}
            </button>
          </div>
        </div>
      ) : (
        <div className="flex flex-1 flex-col gap-5 pt-4">
          <div role="radiogroup" aria-label="Voice language" className="flex gap-1.5 overflow-x-auto">
            {VOICE_LANGS.map((l) => (
              <button
                key={l.value}
                type="button"
                role="radio"
                aria-checked={state.voiceLang === l.value}
                disabled={speech.listening}
                onClick={() => actions.setVoiceLang(l.value)}
                className={cn(
                  'shrink-0 rounded-full border px-3 py-1.5 text-xs font-medium transition-colors disabled:opacity-50',
                  state.voiceLang === l.value ? 'border-primary bg-primary/15 text-primary' : 'border-border text-muted-foreground hover:text-foreground',
                )}
              >
                {l.label}
              </button>
            ))}
          </div>

          <div className="flex flex-col items-center gap-3 py-4">
            <button
              type="button"
              onClick={speech.listening ? speech.stop : speech.start}
              disabled={!supported || phase === 'processing'}
              aria-label={speech.listening ? 'Stop recording' : 'Start recording'}
              className="relative flex size-28 items-center justify-center rounded-full disabled:opacity-40"
            >
              {speech.listening && (
                <>
                  <span aria-hidden="true" className="absolute inset-0 rounded-full bg-primary/40 animate-mic-ripple" />
                  <span aria-hidden="true" className="absolute inset-0 rounded-full bg-accent/40 animate-mic-ripple [animation-delay:0.7s]" />
                </>
              )}
              <span
                className={cn(
                  'relative flex size-full items-center justify-center rounded-full text-primary-foreground transition-all',
                  speech.listening ? 'scale-105 bg-gradient-to-br from-accent to-primary shadow-[0_0_56px] shadow-primary/60' : 'bg-gradient-to-br from-primary to-accent',
                )}
              >
                {speech.listening ? <Square className="size-9 fill-current" aria-hidden="true" /> : <Mic className="size-11" aria-hidden="true" />}
              </span>
            </button>
            <p className="text-sm text-muted-foreground" aria-live="polite">
              {!supported ? 'Voice not supported here — type below' : speech.listening ? 'Listening… tap to stop' : 'Tap the mic to speak'}
            </p>
          </div>

          <label htmlFor="voice-text" className="sr-only">
            Your note
          </label>
          <textarea
            id="voice-text"
            dir="auto"
            value={displayText}
            readOnly={speech.listening}
            onChange={(e) => setText(e.target.value)}
            placeholder='e.g. "Kal 3 baje dentist appointment, aur sabzi bhi leni hai"'
            rows={4}
            maxLength={2000}
            className="w-full resize-none rounded-2xl border border-input bg-card p-4 text-base leading-relaxed placeholder:text-muted-foreground/70 focus:border-primary focus:outline-none"
          />

          {(error || speech.error) && (
            <p role="alert" className="rounded-xl bg-destructive/15 px-3 py-2 text-sm text-destructive">
              {error || speech.error}
            </p>
          )}

          <button
            type="button"
            onClick={process}
            disabled={!displayText.trim() || phase === 'processing'}
            className="mt-auto flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-primary to-accent px-4 py-3.5 text-sm font-semibold text-primary-foreground transition-opacity disabled:opacity-50"
          >
            {phase === 'processing' ? (
              <>
                <LoaderCircle className="size-4 animate-spin" aria-hidden="true" />
                Organizing with AI…
              </>
            ) : (
              <>
                <Wand2 className="size-4" aria-hidden="true" />
                Organize with AI
              </>
            )}
          </button>
        </div>
      )}
    </div>
  )
}
