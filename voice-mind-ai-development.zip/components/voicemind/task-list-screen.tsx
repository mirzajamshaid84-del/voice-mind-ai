'use client'

import { Mic } from 'lucide-react'
import { useState } from 'react'
import { CATEGORIES, CATEGORY_KEYS } from '@/lib/meta'
import type { AppState, Category } from '@/lib/types'
import { cn } from '@/lib/utils'
import { TaskRow } from './task-row'

export function TaskListScreen({ state, onOpenVoice }: { state: AppState; onOpenVoice: () => void }) {
  const [filter, setFilter] = useState<Category | 'all'>('all')
  const visible = filter === 'all' ? state.tasks : state.tasks.filter((t) => t.category === filter)
  const pending = visible.filter((t) => !t.completed)
  const completed = visible.filter((t) => t.completed)

  return (
    <div className="flex flex-col gap-5">
      <header>
        <h1 className="text-2xl font-semibold tracking-tight">Tasks</h1>
        <p className="text-sm text-muted-foreground">
          {pending.length} pending · {completed.length} done
        </p>
      </header>

      <div role="tablist" aria-label="Filter by category" className="-mx-5 flex gap-2 overflow-x-auto px-5 pb-1">
        {(['all', ...CATEGORY_KEYS] as const).map((key) => {
          const active = filter === key
          const meta = key === 'all' ? null : CATEGORIES[key]
          const Icon = meta?.icon
          const count = key === 'all' ? state.tasks.length : state.tasks.filter((t) => t.category === key).length
          return (
            <button
              key={key}
              type="button"
              role="tab"
              aria-selected={active}
              onClick={() => setFilter(key)}
              className={cn(
                'flex shrink-0 items-center gap-1.5 rounded-full border px-3.5 py-2 text-sm font-medium transition-colors',
                active ? 'border-transparent bg-foreground text-background' : 'border-border text-muted-foreground hover:text-foreground',
              )}
            >
              {Icon && <Icon className={cn('size-3.5', !active && meta?.text)} aria-hidden="true" />}
              {meta?.label ?? 'All'}
              <span className="font-mono text-xs opacity-70">{count}</span>
            </button>
          )
        })}
      </div>

      {visible.length === 0 ? (
        <div className="flex flex-col items-center gap-3 rounded-3xl border border-dashed border-border px-6 py-12 text-center">
          <p className="text-sm text-muted-foreground">No tasks here yet.</p>
          <button
            type="button"
            onClick={onOpenVoice}
            className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-primary to-accent px-4 py-2.5 text-sm font-semibold text-primary-foreground"
          >
            <Mic className="size-4" aria-hidden="true" />
            Add by voice
          </button>
        </div>
      ) : (
        <>
          {pending.length > 0 && (
            <section aria-label="Pending" className="flex flex-col gap-2">
              <ul className="flex flex-col gap-2">
                {pending.map((t) => (
                  <TaskRow key={t.id} task={t} showDelete />
                ))}
              </ul>
            </section>
          )}
          {completed.length > 0 && (
            <section aria-labelledby="done-heading" className="flex flex-col gap-2">
              <h2 id="done-heading" className="text-sm font-medium text-muted-foreground">
                Completed
              </h2>
              <ul className="flex flex-col gap-2 opacity-80">
                {completed.map((t) => (
                  <TaskRow key={t.id} task={t} showDelete />
                ))}
              </ul>
            </section>
          )}
        </>
      )}
    </div>
  )
}
