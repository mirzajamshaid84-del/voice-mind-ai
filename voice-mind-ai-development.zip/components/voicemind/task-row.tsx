'use client'

import { Bell, CalendarDays, Check, StickyNote, Trash2 } from 'lucide-react'
import { formatDue } from '@/lib/date'
import { CATEGORIES } from '@/lib/meta'
import { actions } from '@/lib/store'
import type { Task } from '@/lib/types'
import { cn } from '@/lib/utils'

export function TaskRow({ task, showDelete = false }: { task: Task; showDelete?: boolean }) {
  const cat = CATEGORIES[task.category]
  const CatIcon = cat.icon
  const due = formatDue(task)
  const KindIcon = task.kind === 'event' ? CalendarDays : task.kind === 'note' ? StickyNote : Bell

  return (
    <li className="group flex items-center gap-3 rounded-2xl border border-border bg-card px-3.5 py-3 animate-in fade-in slide-in-from-bottom-1">
      <button
        type="button"
        onClick={() => actions.toggleTask(task.id)}
        aria-label={task.completed ? `Mark "${task.title}" as not done` : `Mark "${task.title}" as done`}
        aria-pressed={task.completed}
        className={cn(
          'flex size-6 shrink-0 items-center justify-center rounded-full border-2 transition-colors',
          task.completed ? 'border-primary bg-primary text-primary-foreground' : 'border-muted-foreground/50 hover:border-primary',
        )}
      >
        {task.completed && <Check className="size-3.5 animate-check-pop" strokeWidth={3} aria-hidden="true" />}
      </button>

      <div className="min-w-0 flex-1">
        <p
          dir="auto"
          className={cn(
            'truncate text-sm font-medium transition-colors',
            task.completed && 'text-muted-foreground line-through',
          )}
        >
          {task.title}
        </p>
        <div className="mt-1 flex items-center gap-2 text-xs text-muted-foreground">
          <span className={cn('inline-flex items-center gap-1 rounded-full px-2 py-0.5 font-medium', cat.bg, cat.text)}>
            <CatIcon className="size-3" aria-hidden="true" />
            {cat.label}
          </span>
          {due && (
            <span className="inline-flex items-center gap-1 font-mono">
              <KindIcon className="size-3" aria-hidden="true" />
              {due}
            </span>
          )}
        </div>
      </div>

      {showDelete && (
        <button
          type="button"
          onClick={() => actions.deleteTask(task.id)}
          aria-label={`Delete "${task.title}"`}
          className="rounded-lg p-2 text-muted-foreground transition-colors hover:bg-destructive/15 hover:text-destructive"
        >
          <Trash2 className="size-4" aria-hidden="true" />
        </button>
      )}
    </li>
  )
}
