'use client'

import { useState, useSyncExternalStore } from 'react'
import { hasVoiceCredit, useAppState } from '@/lib/store'
import { BottomNav, type Tab } from './bottom-nav'
import { HomeScreen } from './home-screen'
import { ProSheet } from './pro-sheet'
import { StatsScreen } from './stats-screen'
import { TaskListScreen } from './task-list-screen'
import { VoiceOverlay } from './voice-overlay'

const noopSubscribe = () => () => {}

export function AppShell() {
  const isClient = useSyncExternalStore(noopSubscribe, () => true, () => false)
  const state = useAppState()
  const [tab, setTab] = useState<Tab>('home')
  const [voiceOpen, setVoiceOpen] = useState(false)
  const [proOpen, setProOpen] = useState(false)

  const openVoice = () => {
    if (hasVoiceCredit(state)) setVoiceOpen(true)
    else setProOpen(true)
  }

  if (!isClient) {
    return (
      <div className="flex min-h-dvh items-center justify-center" aria-busy="true">
        <span className="size-10 animate-pulse rounded-full bg-gradient-to-br from-primary to-accent" />
        <span className="sr-only">Loading VoiceMind AI</span>
      </div>
    )
  }

  return (
    <div className="relative mx-auto flex min-h-dvh max-w-md flex-col">
      <div
        aria-hidden="true"
        className="pointer-events-none fixed inset-x-0 top-0 -z-10 mx-auto h-72 max-w-md bg-[radial-gradient(ellipse_at_top,var(--color-accent)/0.18,transparent_70%)]"
      />
      <main className="flex-1 px-5 pt-6 pb-28">
        {tab === 'home' && (
          <HomeScreen state={state} onOpenVoice={openVoice} onOpenPro={() => setProOpen(true)} onSeeAll={() => setTab('tasks')} />
        )}
        {tab === 'tasks' && <TaskListScreen state={state} onOpenVoice={openVoice} />}
        {tab === 'stats' && <StatsScreen state={state} onOpenPro={() => setProOpen(true)} />}
      </main>
      <BottomNav tab={tab} onChange={setTab} onOpenVoice={openVoice} />
      {voiceOpen && <VoiceOverlay state={state} onClose={() => setVoiceOpen(false)} />}
      {proOpen && <ProSheet state={state} onClose={() => setProOpen(false)} />}
    </div>
  )
}
