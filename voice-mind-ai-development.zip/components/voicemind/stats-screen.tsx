'use client'

import { Crown, Flame, Target, Trophy } from 'lucide-react'
import { computeStreak, dayKey, lastNDays } from '@/lib/date'
import { CATEGORIES, CATEGORY_KEYS, MOODS } from '@/lib/meta'
import type { AppState } from '@/lib/types'
import { cn } from '@/lib/utils'

export function StatsScreen({ state, onOpenPro }: { state: AppState; onOpenPro: () => void }) {
  const streak = computeStreak(state.tasks)
  const totalDone = state.tasks.filter((t) => t.completed).length
  const rate = state.tasks.length ? Math.round((totalDone / state.tasks.length) * 100) : 0

  const week = lastNDays(7).map((d) => {
    const key = dayKey(d)
    return {
      key,
      label: d.toLocaleDateString(undefined, { weekday: 'narrow' }),
      count: state.tasks.filter((t) => t.completedAt && dayKey(t.completedAt) === key).length,
      mood: state.moods[key],
    }
  })
  const maxCount = Math.max(1, ...week.map((d) => d.count))
  const categoryCounts = CATEGORY_KEYS.map((c) => ({ c, n: state.tasks.filter((t) => t.category === c).length }))
  const maxCat = Math.max(1, ...categoryCounts.map((x) => x.n))

  return (
    <div className="flex flex-col gap-5">
      <header>
        <h1 className="text-2xl font-semibold tracking-tight">Your stats</h1>
        <p className="text-sm text-muted-foreground">Last 7 days at a glance</p>
      </header>

      <div className="grid grid-cols-3 gap-2">
        <StatTile icon={Flame} label="Streak" value={`${streak}d`} className="text-chart-4" />
        <StatTile icon={Trophy} label="Completed" value={String(totalDone)} className="text-primary" />
        <StatTile icon={Target} label="Rate" value={`${rate}%`} className="text-accent" />
      </div>

      <section aria-labelledby="week-heading" className="rounded-3xl border border-border bg-card p-5">
        <h2 id="week-heading" className="text-sm font-medium text-muted-foreground">
          Tasks completed
        </h2>
        <div className="mt-4 flex h-36 items-end gap-2" role="list">
          {week.map((d, i) => (
            <div key={d.key} role="listitem" className="flex flex-1 flex-col items-center gap-2" aria-label={`${d.count} completed`}>
              <span className="font-mono text-xs text-muted-foreground">{d.count || ''}</span>
              <div
                className={cn(
                  'w-full rounded-lg transition-[height] duration-500',
                  i === 6 ? 'bg-gradient-to-t from-accent to-primary' : 'bg-primary/35',
                )}
                style={{ height: `${Math.max(6, (d.count / maxCount) * 100)}px` }}
              />
              <span className="text-xs text-muted-foreground">{d.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section aria-labelledby="mood-week-heading" className="rounded-3xl border border-border bg-card p-5">
        <h2 id="mood-week-heading" className="text-sm font-medium text-muted-foreground">
          Mood journal
        </h2>
        <ul className="mt-4 flex justify-between">
          {week.map((d) => {
            const mood = MOODS.find((m) => m.value === d.mood)
            const Icon = mood?.icon
            return (
              <li key={d.key} className="flex flex-col items-center gap-2">
                <span
                  className={cn(
                    'flex size-9 items-center justify-center rounded-full',
                    mood ? 'bg-accent/20 text-accent' : 'border border-dashed border-border',
                  )}
                >
                  {Icon && <Icon className="size-5" aria-hidden="true" />}
                  <span className="sr-only">{mood?.label ?? 'Not logged'}</span>
                </span>
                <span className="text-xs text-muted-foreground">{d.label}</span>
              </li>
            )
          })}
        </ul>
      </section>

      <section aria-labelledby="cat-heading" className="rounded-3xl border border-border bg-card p-5">
        <h2 id="cat-heading" className="text-sm font-medium text-muted-foreground">
          By category
        </h2>
        <ul className="mt-4 flex flex-col gap-3">
          {categoryCounts.map(({ c, n }) => {
            const meta = CATEGORIES[c]
            const Icon = meta.icon
            return (
              <li key={c} className="flex items-center gap-3">
                <Icon className={cn('size-4 shrink-0', meta.text)} aria-hidden="true" />
                <span className="w-20 text-sm">{meta.label}</span>
                <div className="h-2 flex-1 overflow-hidden rounded-full bg-muted">
                  <div className={cn('h-full rounded-full', meta.bar)} style={{ width: `${(n / maxCat) * 100}%` }} />
                </div>
                <span className="w-6 text-right font-mono text-sm text-muted-foreground">{n}</span>
              </li>
            )
          })}
        </ul>
      </section>

      {!state.isPro && (
        <button
          type="button"
          onClick={onOpenPro}
          className="flex items-center gap-3 rounded-3xl border border-chart-4/30 bg-chart-4/10 p-4 text-left transition-colors hover:bg-chart-4/15"
        >
          <Crown className="size-6 shrink-0 text-chart-4" aria-hidden="true" />
          <div>
            <p className="font-semibold">Unlock advanced analytics</p>
            <p className="text-xs text-muted-foreground">Monthly trends, habit insights, and more with Pro.</p>
          </div>
        </button>
      )}
    </div>
  )
}

function StatTile({
  icon: Icon,
  label,
  value,
  className,
}: {
  icon: typeof Flame
  label: string
  value: string
  className: string
}) {
  return (
    <div className="flex flex-col gap-2 rounded-2xl border border-border bg-card p-3.5">
      <Icon className={cn('size-5', className)} aria-hidden="true" />
      <p className="font-mono text-xl font-semibold">{value}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
    </div>
  )
}
