'use client'

import { Check, Crown, X } from 'lucide-react'
import { useEffect } from 'react'
import { FREE_DAILY_VOICE_LIMIT, hasVoiceCredit } from '@/lib/store'
import type { AppState } from '@/lib/types'

const ROWS = [
  { label: 'Voice tasks per day', free: String(FREE_DAILY_VOICE_LIMIT), pro: 'Unlimited' },
  { label: 'AI categorization & reminders', free: true, pro: true },
  { label: 'Daily AI insight & share card', free: true, pro: true },
  { label: 'Advanced analytics', free: false, pro: true },
  { label: 'Custom AI themes', free: false, pro: true },
  { label: 'WhatsApp reminders', free: false, pro: true },
  { label: 'Ad-free', free: false, pro: true },
]

export function ProSheet({ state, onClose }: { state: AppState; onClose: () => void }) {
  const outOfCredits = !hasVoiceCredit(state)

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [onClose])

  return (
    <div className="fixed inset-0 z-50 mx-auto flex max-w-md items-end bg-background/70 backdrop-blur-sm animate-in fade-in" onClick={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="pro-title"
        onClick={(e) => e.stopPropagation()}
        className="w-full rounded-t-3xl border-t border-border bg-card px-5 pt-5 pb-[max(1.25rem,env(safe-area-inset-bottom))] animate-in slide-in-from-bottom"
      >
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2">
            <Crown className="size-5 text-chart-4" aria-hidden="true" />
            <h2 id="pro-title" className="text-lg font-semibold">
              VoiceMind Pro
            </h2>
          </div>
          <button type="button" onClick={onClose} aria-label="Close" className="rounded-full p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground">
            <X className="size-5" aria-hidden="true" />
          </button>
        </div>
        {outOfCredits && (
          <p className="mt-2 text-sm text-muted-foreground">
            {"You've used all "}
            {FREE_DAILY_VOICE_LIMIT}
            {' free voice tasks today. They reset at midnight.'}
          </p>
        )}

        <table className="mt-4 w-full text-sm">
          <thead>
            <tr className="text-xs text-muted-foreground">
              <th className="pb-2 text-left font-medium">Feature</th>
              <th className="pb-2 text-center font-medium">Free</th>
              <th className="pb-2 text-center font-medium text-chart-4">Pro</th>
            </tr>
          </thead>
          <tbody>
            {ROWS.map((r) => (
              <tr key={r.label} className="border-t border-border">
                <td className="py-2.5">{r.label}</td>
                <Cell value={r.free} />
                <Cell value={r.pro} />
              </tr>
            ))}
          </tbody>
        </table>

        <button
          type="button"
          disabled
          className="mt-5 w-full rounded-xl bg-gradient-to-r from-chart-4 to-accent px-4 py-3.5 text-sm font-semibold text-primary-foreground opacity-70"
        >
          Pro launches with the Play Store release
        </button>
      </div>
    </div>
  )
}

function Cell({ value }: { value: string | boolean }) {
  return (
    <td className="py-2.5 text-center">
      {typeof value === 'string' ? (
        <span className="font-mono text-xs">{value}</span>
      ) : value ? (
        <Check className="mx-auto size-4 text-primary" aria-label="Included" />
      ) : (
        <span className="text-muted-foreground" aria-label="Not included">
          —
        </span>
      )}
    </td>
  )
}
