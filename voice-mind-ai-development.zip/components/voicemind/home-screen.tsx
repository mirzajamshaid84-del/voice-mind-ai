'use client'

import { Crown, Flame, Mic } from 'lucide-react'
import { computeStreak, dayKey, isTodayTask } from '@/lib/date'
import { FREE_DAILY_VOICE_LIMIT, voiceCreditsUsed } from '@/lib/store'
import type { AppState } from '@/lib/types'
import { DailySummaryCard } from './daily-summary-card'
import { MoodPicker } from './mood-picker'
import { TaskRow } from './task-row'

function greeting() {
  const h = new Date().getHours()
  if (h < 12) return 'Good morning'
  if (h < 17) return 'Good afternoon'
  return 'Good evening'
}

export function HomeScreen({
  state,
  onOpenVoice,
  onOpenPro,
  onSeeAll,
}: {
  state: AppState
  onOpenVoice: () => void
  onOpenPro: () => void
  onSeeAll: () => void
}) {
  const today = dayKey()
  const todayTasks = state.tasks.filter((t) => isTodayTask(t, today))
  const done = todayTasks.filter((t) => t.completed).length
  const total = todayTasks.length
  const pct = total ? Math.round((done / total) * 100) : 0
  const streak = computeStreak(state.tasks)
  const upcoming = state.tasks.filter((t) => !t.completed && (!t.dueDate || t.dueDate <= today)).slice(0, 4)
  const creditsLeft = Math.max(0, FREE_DAILY_VOICE_LIMIT - voiceCreditsUsed(state))

  return (
    <div className="flex flex-col gap-6">
      <header className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted-foreground">{greeting()}</p>
          <h1 className="text-2xl font-semibold tracking-tight text-balance">What&apos;s on your mind?</h1>
        </div>
        <div
          className="flex items-center gap-1.5 rounded-full border border-chart-4/30 bg-chart-4/10 px-3 py-1.5 text-sm font-semibold text-chart-4"
          aria-label={`${streak} day streak`}
        >
          <Flame className="size-4" aria-hidden="true" />
          <span className="font-mono">{streak}</span>
        </div>
      </header>

      <section aria-labelledby="progress-heading" className="rounded-3xl border border-border bg-card p-5">
        <div className="flex items-baseline justify-between">
          <h2 id="progress-heading" className="text-sm font-medium text-muted-foreground">
            {"Today's progress"}
          </h2>
          <p className="font-mono text-sm">
            <span className="text-lg font-semibold text-foreground">{done}</span>
            <span className="text-muted-foreground">/{total}</span>
          </p>
        </div>
        <div
          className="mt-3 h-2.5 overflow-hidden rounded-full bg-muted"
          role="progressbar"
          aria-valuenow={pct}
          aria-valuemin={0}
          aria-valuemax={100}
          aria-label="Tasks completed today"
        >
          <div
            className="h-full rounded-full bg-gradient-to-r from-primary to-accent transition-[width] duration-500 ease-out"
            style={{ width: `${pct}%` }}
          />
        </div>
        <p className="mt-2 text-xs text-muted-foreground">
          {total === 0 ? 'Add your first task by voice to get started.' : pct === 100 ? 'All done. Incredible work!' : `${pct}% complete — keep going.`}
        </p>
      </section>

      <section aria-label="Voice assistant" className="flex flex-col items-center gap-4 py-4">
        <button
          type="button"
          onClick={onOpenVoice}
          aria-label="Tap to speak"
          className="relative flex size-36 items-center justify-center rounded-full transition-transform active:scale-95"
        >
          <span aria-hidden="true" className="absolute inset-0 rounded-full bg-primary/30 animate-mic-ripple" />
          <span aria-hidden="true" className="absolute inset-0 rounded-full bg-accent/30 animate-mic-ripple [animation-delay:1s]" />
          <span className="relative flex size-full items-center justify-center rounded-full bg-gradient-to-br from-primary to-accent text-primary-foreground shadow-[0_0_48px] shadow-accent/50">
            <Mic className="size-14" strokeWidth={1.75} aria-hidden="true" />
          </span>
        </button>
        <div className="text-center">
          <p className="font-medium">Tap to speak</p>
          <p className="text-xs text-muted-foreground">English · اردو · हिन्दी · Roman Urdu</p>
        </div>
        {state.isPro ? (
          <p className="text-xs text-primary">Pro · Unlimited voice tasks</p>
        ) : (
          <button
            type="button"
            onClick={onOpenPro}
            className="flex items-center gap-1.5 rounded-full bg-muted px-3 py-1 text-xs text-muted-foreground transition-colors hover:text-foreground"
          >
            <span className="font-mono text-foreground">{creditsLeft}</span> of {FREE_DAILY_VOICE_LIMIT} free voice tasks left
            <Crown className="size-3.5 text-chart-4" aria-hidden="true" />
          </button>
        )}
      </section>

      <MoodPicker value={state.moods[today] ?? null} />

      <section aria-labelledby="upnext-heading" className="flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <h2 id="upnext-heading" className="font-semibold">
            Up next
          </h2>
          {state.tasks.length > 0 && (
            <button type="button" onClick={onSeeAll} className="text-sm text-primary hover:underline">
              See all
            </button>
          )}
        </div>
        {upcoming.length === 0 ? (
          <p className="rounded-2xl border border-dashed border-border px-4 py-6 text-center text-sm text-muted-foreground">
            {state.tasks.length ? 'Nothing pending for today.' : 'Try saying: "Kal subah 10 baje client meeting, aur doodh lena hai"'}
          </p>
        ) : (
          <ul className="flex flex-col gap-2">
            {upcoming.map((t) => (
              <TaskRow key={t.id} task={t} />
            ))}
          </ul>
        )}
      </section>

      <DailySummaryCard state={state} done={done} total={total} streak={streak} />
    </div>
  )
}
