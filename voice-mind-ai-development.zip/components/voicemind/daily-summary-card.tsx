'use client'

import { LoaderCircle, Share2, Sparkles } from 'lucide-react'
import { useState } from 'react'
import { dayKey, isTodayTask } from '@/lib/date'
import { shareAchievement } from '@/lib/share-card'
import { actions } from '@/lib/store'
import type { AppState } from '@/lib/types'

export function DailySummaryCard({
  state,
  done,
  total,
  streak,
}: {
  state: AppState
  done: number
  total: number
  streak: number
}) {
  const today = dayKey()
  const summary = state.summaries[today] ?? null
  const [loading, setLoading] = useState(false)
  const [sharing, setSharing] = useState(false)
  const [message, setMessage] = useState<string | null>(null)

  async function generate() {
    setLoading(true)
    setMessage(null)
    try {
      const todayTasks = state.tasks.filter((t) => isTodayTask(t, today))
      const res = await fetch('/api/summary', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          completed: todayTasks.filter((t) => t.completed).slice(0, 30).map((t) => t.title.slice(0, 200)),
          pendingCount: todayTasks.filter((t) => !t.completed).length,
          mood: state.moods[today] ?? null,
          streak,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      actions.setSummary(data.summary)
    } catch (err) {
      setMessage((err as Error).message || 'Something went wrong.')
    } finally {
      setLoading(false)
    }
  }

  async function share() {
    setSharing(true)
    setMessage(null)
    try {
      const result = await shareAchievement({ streak, completed: done, total, summary })
      if (result === 'downloaded') setMessage('Card saved. Post it to your WhatsApp or Instagram Story.')
    } catch {
      setMessage('Could not create the share card.')
    } finally {
      setSharing(false)
    }
  }

  return (
    <section
      aria-labelledby="summary-heading"
      className="relative overflow-hidden rounded-3xl border border-accent/30 bg-gradient-to-br from-accent/20 via-card to-primary/10 p-5"
    >
      <div className="flex items-center gap-2">
        <Sparkles className="size-4 text-accent" aria-hidden="true" />
        <h2 id="summary-heading" className="font-semibold">
          AI daily insight
        </h2>
      </div>

      <p dir="auto" className="mt-3 text-sm leading-relaxed text-pretty text-foreground/90" aria-live="polite">
        {summary ?? 'Get a 2-sentence reflection on your day based on what you finished and how you feel.'}
      </p>

      <div className="mt-4 flex gap-2">
        <button
          type="button"
          onClick={generate}
          disabled={loading}
          className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-foreground px-4 py-2.5 text-sm font-semibold text-background transition-opacity hover:opacity-90 disabled:opacity-60"
        >
          {loading ? <LoaderCircle className="size-4 animate-spin" aria-hidden="true" /> : <Sparkles className="size-4" aria-hidden="true" />}
          {summary ? 'Refresh' : 'Generate'}
        </button>
        <button
          type="button"
          onClick={share}
          disabled={sharing}
          className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-primary to-accent px-4 py-2.5 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-60"
        >
          <Share2 className="size-4" aria-hidden="true" />
          Share
        </button>
      </div>
      {message && (
        <p className="mt-3 text-xs text-muted-foreground" role="status">
          {message}
        </p>
      )}
    </section>
  )
}
