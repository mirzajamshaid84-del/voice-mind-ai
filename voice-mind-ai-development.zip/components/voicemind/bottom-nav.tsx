'use client'

import { ChartColumn, House, ListChecks, Mic } from 'lucide-react'
import { cn } from '@/lib/utils'

export type Tab = 'home' | 'tasks' | 'stats'

const ITEMS = [
  { id: 'home', label: 'Home', icon: House },
  { id: 'tasks', label: 'Tasks', icon: ListChecks },
  { id: 'stats', label: 'Stats', icon: ChartColumn },
] as const

export function BottomNav({
  tab,
  onChange,
  onOpenVoice,
}: {
  tab: Tab
  onChange: (tab: Tab) => void
  onOpenVoice: () => void
}) {
  return (
    <nav
      aria-label="Main"
      className="fixed inset-x-0 bottom-0 z-30 mx-auto max-w-md border-t border-border bg-background/85 px-4 pt-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] backdrop-blur-xl"
    >
      <ul className="flex items-center justify-around">
        {ITEMS.slice(0, 2).map((item) => (
          <NavItem key={item.id} item={item} active={tab === item.id} onClick={() => onChange(item.id)} />
        ))}
        <li>
          <button
            type="button"
            onClick={onOpenVoice}
            aria-label="New voice task"
            className="-mt-7 flex size-14 items-center justify-center rounded-full bg-gradient-to-br from-primary to-accent text-primary-foreground shadow-[0_0_24px] shadow-accent/50 transition-transform active:scale-95"
          >
            <Mic className="size-6" aria-hidden="true" />
          </button>
        </li>
        {ITEMS.slice(2).map((item) => (
          <NavItem key={item.id} item={item} active={tab === item.id} onClick={() => onChange(item.id)} />
        ))}
      </ul>
    </nav>
  )
}

function NavItem({
  item,
  active,
  onClick,
}: {
  item: (typeof ITEMS)[number]
  active: boolean
  onClick: () => void
}) {
  const Icon = item.icon
  return (
    <li>
      <button
        type="button"
        onClick={onClick}
        aria-current={active ? 'page' : undefined}
        className={cn(
          'flex min-w-16 flex-col items-center gap-1 rounded-lg px-3 py-1.5 text-xs font-medium transition-colors',
          active ? 'text-primary' : 'text-muted-foreground hover:text-foreground',
        )}
      >
        <Icon className="size-5" aria-hidden="true" />
        {item.label}
      </button>
    </li>
  )
}
