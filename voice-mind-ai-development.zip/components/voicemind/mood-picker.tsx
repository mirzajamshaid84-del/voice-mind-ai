'use client'

import { MOODS } from '@/lib/meta'
import { actions } from '@/lib/store'
import type { Mood } from '@/lib/types'
import { cn } from '@/lib/utils'

export function MoodPicker({ value }: { value: Mood | null }) {
  return (
    <section aria-labelledby="mood-heading" className="rounded-3xl border border-border bg-card p-4">
      <h2 id="mood-heading" className="text-sm font-medium text-muted-foreground">
        How are you feeling today?
      </h2>
      <div role="radiogroup" aria-labelledby="mood-heading" className="mt-3 flex justify-between gap-1">
        {MOODS.map((m) => {
          const Icon = m.icon
          const active = value === m.value
          return (
            <button
              key={m.value}
              type="button"
              role="radio"
              aria-checked={active}
              onClick={() => actions.setMood(m.value)}
              className={cn(
                'flex flex-1 flex-col items-center gap-1 rounded-xl py-2 text-xs transition-all',
                active ? 'bg-accent/20 text-accent' : 'text-muted-foreground hover:bg-muted hover:text-foreground',
              )}
            >
              <Icon className={cn('size-6 transition-transform', active && 'scale-110')} aria-hidden="true" />
              {m.label}
            </button>
          )
        })}
      </div>
    </section>
  )
}
